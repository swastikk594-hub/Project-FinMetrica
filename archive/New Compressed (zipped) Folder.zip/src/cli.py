"""
QuantFinance Institutional Command Line Interface (CLI)
========================================================
Usage:
  python -m src.cli --tickers AAPL MSFT GOOGL JPM XOM --start 2018-01-01
  python -m src.cli --tickers AAPL MSFT --start 2018-01-01 --no-backtest
  python -m src.cli --help
"""

import argparse
import os
import sys
from datetime import datetime

try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.text import Text
    HAS_RICH = True
except ImportError:
    HAS_RICH = False

from src.pipeline import QuantFinancePipeline


def print_banner():
    if HAS_RICH:
        console = Console()
        banner_text = Text(
            "========================================================\n"
            "   QuantFinance: Institutional Research & Risk System   \n"
            "========================================================",
            style="bold cyan",
            justify="center"
        )
        console.print(Panel(banner_text, border_style="cyan"))
    else:
        print("========================================================")
        print("   QuantFinance: Institutional Research & Risk System   ")
        print("========================================================")


def main():
    parser = argparse.ArgumentParser(
        description="QuantFinance Institutional Quantitative Research & Portfolio System",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    parser.add_argument('--tickers', nargs='+', required=True,
                        help='List of ticker symbols to analyze (e.g., AAPL MSFT GOOGL JPM XOM)')

    parser.add_argument('--start', type=str, default='2018-01-01',
                        help='Start date for historical data (YYYY-MM-DD)')

    parser.add_argument('--end', type=str, default=datetime.today().strftime('%Y-%m-%d'),
                        help='End date for historical data (YYYY-MM-DD)')

    parser.add_argument('--config', type=str, default=None,
                        help='Path to YAML configuration file')

    parser.add_argument('--no-backtest', action='store_true',
                        help='Flag to skip walk-forward backtest')

    parser.add_argument('--no-stress', action='store_true',
                        help='Flag to skip crisis stress testing')

    parser.add_argument('--mode', type=str, choices=['research', 'execute', 'advise'], default='research',
                        help='Operating mode: research (backtest), execute (order generation), or advise (investment horizons)')

    parser.add_argument('--capital', type=float, default=100000.0,
                        help='Total capital (AUM) in USD to deploy (for execute and advise modes)')

    parser.add_argument('--current-holdings', type=str, default='{}',
                        help='JSON string of current ticker holdings e.g., {"AAPL": 50, "TSLA": 10}')

    parser.add_argument('--output-dir', type=str, default='results/',
                        help='Directory to save results JSON and audit trail')

    parser.add_argument('--alpaca-key', type=str, default=None,
                        help='Alpaca Paper Trading API Key')
    parser.add_argument('--alpaca-secret', type=str, default=None,
                        help='Alpaca Paper Trading Secret Key')
    parser.add_argument('--live-trade', action='store_true',
                        help='If set, executes orders on Alpaca Paper Trading')
    parser.add_argument('--modules', type=int, nargs='+', default=None,
                        help='Specific module numbers to run (1-9)')

    args = parser.parse_args()

    print_banner()
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    import json
    current_holdings = {}
    try:
        current_holdings = json.loads(args.current_holdings)
    except json.JSONDecodeError:
        pass

    capital = args.capital
    alpaca_broker = None

    if args.alpaca_key and args.alpaca_secret:
        from src.execution.alpaca_broker import AlpacaBroker
        alpaca_broker = AlpacaBroker(args.alpaca_key, args.alpaca_secret)
        
        # Override holdings and capital with live Alpaca data
        print(f"Connecting to Alpaca Paper Trading...")
        acc_info = alpaca_broker.get_account_info()
        if acc_info:
            capital = float(acc_info.get('portfolio_value', args.capital))
            print(f"Live Alpaca Portfolio Value: ${capital:,.2f}")
            
        live_holdings = alpaca_broker.get_current_holdings()
        if live_holdings:
            current_holdings = live_holdings
            print(f"Live Alpaca Holdings: {current_holdings}")
            
    pipeline = QuantFinancePipeline(
        tickers=args.tickers,
        start=args.start,
        end=args.end,
        config_path=args.config
    )

    run_bt = not args.no_backtest if args.mode == 'research' else False
    run_st = not args.no_stress if args.mode == 'research' else False

    results = pipeline.run(
        modules=args.modules,
        run_backtest=run_bt,
        run_stress=run_st,
        mode=args.mode,
        capital=capital,
        current_holdings=current_holdings
    )

    if results:
        pipeline.print_report(results)
        pipeline.save_results(results, args.output_dir)
        
        if args.mode == 'execute' and args.live_trade and alpaca_broker:
            print("\n[LIVE TRADE] Submitting execution tickets to Alpaca Paper API...")
            tickets = results.get('execution', {}).get('tickets', [])
            if tickets:
                alpaca_broker.submit_orders(tickets)
                print("[LIVE TRADE] Orders successfully dispatched!")
            else:
                print("[LIVE TRADE] No orders generated (Turnover constraints met).")

if __name__ == '__main__':
    main()
