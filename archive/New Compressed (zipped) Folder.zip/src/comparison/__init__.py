"""Init for src.comparison"""
