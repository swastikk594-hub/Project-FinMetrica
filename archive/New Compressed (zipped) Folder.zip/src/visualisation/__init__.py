"""Init for src.visualisation"""
