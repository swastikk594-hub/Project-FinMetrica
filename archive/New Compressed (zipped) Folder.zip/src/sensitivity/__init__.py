"""Init for src.sensitivity"""
