"""Init for src.backtesting"""
