"""
Combinatorial Purged Cross-Validation (CPCV), Purging & Embargo Engine
======================================================================
PURPOSE:
  Prevent data leakage and backtest overfitting across overlapping label horizons.

MATHEMATICAL FOUNDATION (Marcos Lopez de Prado, 2018):
  Standard k-fold cross-validation fails in finance because:
  1. Financial time series exhibit serial correlation.
  2. Forward-looking labels (e.g., 20-day return y_t = r_{t -> t+20}) span
     multiple future days. If sample t is in training and sample t+5 is in test,
     information from the test set leaks into the training set (leakage).

PURGING:
  Drop all training observations whose label evaluation window [t, t + horizon]
  overlaps with any test observation's window [t_test, t_test + horizon].

EMBARGO:
  After the end of a test window, discard an additional embargo window
  (e.g., 5 to 20 days) from training to account for auto-regressive memory.

COMBINATORIAL PATH GENERATION:
  Given N groups, choose k test groups per split, yielding (N choose k) splits
  and generating multiple unique backtest paths for robust distribution estimation.
"""

import itertools
import numpy as np
import pandas as pd
from typing import List, Tuple, Generator, Dict, Any
import logging

logger = logging.getLogger(__name__)


class PurgedCrossValidator:
    """
    Implements Purged and Embargoed Time-Series Cross Validation.
    """

    def __init__(
        self,
        n_splits: int = 5,
        horizon_days: int = 20,
        embargo_pct: float = 0.01,
        combinatorial: bool = False,
        n_test_groups: int = 2
    ):
        self.n_splits = n_splits
        self.horizon_days = horizon_days
        self.embargo_pct = embargo_pct
        self.combinatorial = combinatorial
        self.n_test_groups = n_test_groups

    def split(
        self,
        index: pd.DatetimeIndex
    ) -> Generator[Tuple[np.ndarray, np.ndarray], None, None]:
        """
        Yields (train_indices, test_indices) with purging and embargoing applied.
        """
        n_samples = len(index)
        if n_samples < 20:
            yield np.arange(n_samples), np.arange(n_samples)
            return

        embargo_samples = int(n_samples * self.embargo_pct)
        group_size = n_samples // self.n_splits
        groups = [
            np.arange(i * group_size, (i + 1) * group_size if i < self.n_splits - 1 else n_samples)
            for i in range(self.n_splits)
        ]

        if not self.combinatorial:
            # Standard Purged K-Fold
            for i in range(self.n_splits):
                test_idx = groups[i]
                t_test_start = index[test_idx[0]]
                t_test_end = index[test_idx[-1]]

                # Purge training: remove samples whose label window overlaps test
                train_idx_list = []
                for j in range(self.n_splits):
                    if i == j:
                        continue
                    grp_idx = groups[j]
                    for idx_val in grp_idx:
                        t_obs = index[idx_val]
                        # Label spans [t_obs, t_obs + horizon_days]
                        t_obs_end = t_obs + pd.Timedelta(days=self.horizon_days)

                        # Check overlap
                        overlaps = not (t_obs_end < t_test_start or t_obs > t_test_end)
                        # Check embargo: if group comes right after test group
                        is_embargoed = (j > i) and (idx_val <= test_idx[-1] + embargo_samples)

                        if not overlaps and not is_embargoed:
                            train_idx_list.append(idx_val)

                yield np.array(train_idx_list, dtype=int), test_idx
        else:
            # Combinatorial Purged K-Fold (CPCV)
            group_indices = list(range(self.n_splits))
            for test_comb in itertools.combinations(group_indices, self.n_test_groups):
                test_idx = np.concatenate([groups[g] for g in test_comb])
                test_ranges = [(index[groups[g][0]], index[groups[g][-1]], groups[g][-1]) for g in test_comb]

                train_idx_list = []
                for g in group_indices:
                    if g in test_comb:
                        continue
                    for idx_val in groups[g]:
                        t_obs = index[idx_val]
                        t_obs_end = t_obs + pd.Timedelta(days=self.horizon_days)

                        # Purge & Embargo check against all active test groups
                        purged = False
                        for (t_start, t_end, last_test_idx) in test_ranges:
                            overlaps = not (t_obs_end < t_start or t_obs > t_end)
                            is_embargoed = (idx_val > last_test_idx) and (idx_val <= last_test_idx + embargo_samples)
                            if overlaps or is_embargoed:
                                purged = True
                                break

                        if not purged:
                            train_idx_list.append(idx_val)

                yield np.array(train_idx_list, dtype=int), test_idx
