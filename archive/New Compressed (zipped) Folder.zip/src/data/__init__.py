"""Init for src.data"""
